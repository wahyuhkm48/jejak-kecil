-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: jejak-kecil
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `log_aktivitas`
--

DROP TABLE IF EXISTS `log_aktivitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_aktivitas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pengguna` bigint unsigned NOT NULL,
  `aktivitas` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_tabel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_id` bigint unsigned DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `dibuat_pada` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `log_aktivitas_id_pengguna_foreign` (`id_pengguna`),
  CONSTRAINT `log_aktivitas_id_pengguna_foreign` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_aktivitas`
--

LOCK TABLES `log_aktivitas` WRITE;
/*!40000 ALTER TABLE `log_aktivitas` DISABLE KEYS */;
INSERT INTO `log_aktivitas` VALUES (1,1,'login','pengguna',1,'Login ke sistem','2026-06-14 09:18:12'),(2,1,'logout','pengguna',1,'Logout dari sistem','2026-06-14 09:18:21'),(3,1,'login','pengguna',1,'Login ke sistem','2026-06-14 10:15:43'),(4,1,'logout','pengguna',1,'Logout dari sistem','2026-06-14 10:24:15'),(5,2,'login','pengguna',2,'Login ke sistem','2026-06-14 10:24:28'),(6,2,'hapus','kuis',1,'Menghapus kuis id: 1','2026-06-14 10:28:44'),(7,2,'hapus','kuis',2,'Menghapus kuis id: 2','2026-06-14 10:28:47'),(8,2,'hapus','kuis',3,'Menghapus kuis id: 3','2026-06-14 10:28:52'),(9,2,'hapus','kuis',4,'Menghapus kuis id: 4','2026-06-14 10:28:57'),(10,2,'hapus','kuis',5,'Menghapus kuis id: 5','2026-06-14 10:29:00'),(11,1,'login','pengguna',1,'Login ke sistem','2026-06-14 10:33:38'),(12,1,'login','pengguna',1,'Login ke sistem','2026-06-14 10:35:03'),(13,1,'hapus','kuis',6,'Menghapus kuis id: 6','2026-06-14 10:36:29'),(14,1,'hapus','kuis',7,'Menghapus kuis id: 7','2026-06-14 10:36:34'),(15,1,'hapus','kuis',8,'Menghapus kuis id: 8','2026-06-14 10:36:51'),(16,1,'hapus','kuis',9,'Menghapus kuis id: 9','2026-06-14 10:37:00'),(17,1,'hapus','kuis',10,'Menghapus kuis id: 10','2026-06-14 10:37:07'),(18,2,'login','pengguna',2,'Login ke sistem','2026-06-14 10:46:37'),(19,2,'login','pengguna',2,'Login ke sistem','2026-06-14 10:48:16'),(20,2,'login','pengguna',2,'Login ke sistem','2026-06-14 10:48:57'),(21,1,'login','pengguna',1,'Login ke sistem','2026-06-14 10:51:43'),(22,1,'tambah','modul',3,'Menambahkan modul: Mengenal warna primer dan warna sekunder','2026-06-14 11:15:21'),(23,1,'logout','pengguna',1,'Logout dari sistem','2026-06-14 11:16:00'),(24,2,'login','pengguna',2,'Login ke sistem','2026-06-14 11:16:14'),(25,1,'login','pengguna',1,'Login ke sistem','2026-06-14 11:17:36'),(26,1,'update','modul',3,'Mengupdate modul: Mengenal warna primer dan warna sekunder','2026-06-14 11:18:03'),(27,1,'tambah','kuis',21,'Menambahkan kuis: Mengenal warna primer dan warna sekunder','2026-06-14 11:21:29'),(28,1,'tambah','kuis',22,'Menambahkan kuis: Mengenal warna primer dan warna sekunder','2026-06-14 11:22:37'),(29,1,'update','modul',3,'Mengupdate modul: Mengenal warna primer dan warna sekunder','2026-06-14 11:40:52'),(30,1,'tambah','kuis',23,'Menambahkan kuis: Mengenal warna primer dan warna sekunder','2026-06-14 11:43:15'),(31,1,'update','kuis',22,'Mengupdate kuis id: 22','2026-06-14 11:43:30'),(32,1,'update','kuis',22,'Mengupdate kuis id: 22','2026-06-14 11:43:53'),(33,1,'tambah','kuis',24,'Menambahkan kuis: Mengenal warna primer dan warna sekunder','2026-06-14 11:44:38'),(34,1,'tambah','kuis',25,'Menambahkan kuis: Mengenal warna primer dan warna sekunder','2026-06-14 11:45:30'),(35,1,'logout','pengguna',1,'Logout dari sistem','2026-06-14 11:52:20'),(36,2,'login','pengguna',2,'Login ke sistem','2026-06-14 11:52:33'),(37,2,'login','pengguna',2,'Login ke sistem','2026-06-14 13:37:58'),(38,1,'login','pengguna',1,'Login ke sistem','2026-06-14 13:57:03'),(39,1,'logout','pengguna',1,'Logout dari sistem','2026-06-14 14:29:33'),(40,1,'login','pengguna',1,'Login ke sistem','2026-06-14 14:38:52'),(41,1,'logout','pengguna',1,'Logout dari sistem','2026-06-14 15:43:23'),(42,2,'login','pengguna',2,'Login ke sistem','2026-06-14 15:44:00'),(43,2,'login','pengguna',2,'Login ke sistem','2026-06-14 15:50:02'),(44,2,'login','pengguna',2,'Login ke sistem','2026-06-14 15:51:21'),(45,3,'login','pengguna',3,'Login ke sistem','2026-06-14 16:12:47'),(46,1,'login','pengguna',1,'Login ke sistem','2026-06-14 16:16:36'),(47,1,'logout','pengguna',1,'Logout dari sistem','2026-06-14 16:19:36'),(48,1,'login','pengguna',1,'Login ke sistem','2026-06-14 16:21:36');
/*!40000 ALTER TABLE `log_aktivitas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-14 23:39:21
