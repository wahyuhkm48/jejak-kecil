-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: jejak-kecil
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `transaksi_poin`
--

DROP TABLE IF EXISTS `transaksi_poin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaksi_poin` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_anak` bigint unsigned NOT NULL,
  `id_avatar_shop` bigint unsigned DEFAULT NULL,
  `tipe` enum('kredit','debit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah_poin` int NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `saldo_setelah` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaksi_poin_id_anak_foreign` (`id_anak`),
  KEY `transaksi_poin_id_avatar_shop_foreign` (`id_avatar_shop`),
  CONSTRAINT `transaksi_poin_id_anak_foreign` FOREIGN KEY (`id_anak`) REFERENCES `anak` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaksi_poin_id_avatar_shop_foreign` FOREIGN KEY (`id_avatar_shop`) REFERENCES `avatar_shop` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaksi_poin`
--

LOCK TABLES `transaksi_poin` WRITE;
/*!40000 ALTER TABLE `transaksi_poin` DISABLE KEYS */;
INSERT INTO `transaksi_poin` VALUES (1,1,NULL,'kredit',100,'Selesai Kuis: Mengenal Huruf Alfabet',100,'2026-06-14 03:14:57','2026-06-14 03:14:57'),(2,1,NULL,'kredit',100,'Selesai Kuis: Mengenal Huruf Alfabet',200,'2026-06-14 03:26:12','2026-06-14 03:26:12'),(3,1,NULL,'kredit',80,'Selesai Kuis: Mengenal Angka 1-10',280,'2026-06-14 03:32:01','2026-06-14 03:32:01'),(4,1,3,'debit',250,'Beli Avatar Lucas',730,'2026-06-14 03:51:16','2026-06-14 03:51:16'),(5,1,2,'debit',250,'Beli Avatar Andrey',480,'2026-06-14 04:16:48','2026-06-14 04:16:48'),(6,1,NULL,'kredit',80,'Selesai Kuis: Penjumlahan Dasar',560,'2026-06-14 05:02:36','2026-06-14 05:02:36'),(7,1,NULL,'kredit',100,'Selesai Kuis: Mengenal Huruf Alfabet',660,'2026-06-14 06:46:48','2026-06-14 06:46:48'),(8,2,NULL,'kredit',20,'Selesai Kuis: Mengenal Huruf Alfabet',20,'2026-06-14 09:14:18','2026-06-14 09:14:18');
/*!40000 ALTER TABLE `transaksi_poin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-14 23:39:21
