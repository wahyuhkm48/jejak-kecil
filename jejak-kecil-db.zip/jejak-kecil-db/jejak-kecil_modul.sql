-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: jejak-kecil
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `modul`
--

DROP TABLE IF EXISTS `modul`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modul` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_gaya_belajar` bigint unsigned NOT NULL,
  `judul_modul` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci,
  `tingkat_kesulitan` enum('mudah','sedang','sulit') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mudah',
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kategori` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Umum',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modul_id_gaya_belajar_foreign` (`id_gaya_belajar`),
  CONSTRAINT `modul_id_gaya_belajar_foreign` FOREIGN KEY (`id_gaya_belajar`) REFERENCES `gaya_belajar` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modul`
--

LOCK TABLES `modul` WRITE;
/*!40000 ALTER TABLE `modul` DISABLE KEYS */;
INSERT INTO `modul` VALUES (1,1,'Mengenal Huruf Alfabet','Modul pembelajaran untuk mengenal huruf A sampai Z','mudah','','Bahasa','2026-06-14 09:33:39','2026-06-14 09:33:39'),(2,1,'Mengenal Angka 1-10','Modul pembelajaran untuk mengenal angka 1 sampai 10','mudah','','Matematika','2026-06-14 09:35:46','2026-06-14 09:35:46'),(3,1,'Mengenal warna primer dan warna sekunder','Modul pembelajaran untuk mengenal warna primer dan warna sekunder','mudah',NULL,'Warna','2026-06-14 04:15:21','2026-06-14 04:40:52'),(5,1,'Penjumlahan Dasar','Belajar menjumlahkan angka dengan cara yang mudah dan menyenangkan.','sedang',NULL,'Matematika','2026-06-14 11:59:04','2026-06-14 11:59:04'),(6,1,'Pengurangan Dasar','Belajar mengurangi angka dengan cara yang mudah dipahami.','sedang',NULL,'Matematika','2026-06-14 11:59:33','2026-06-14 11:59:33'),(7,1,'Perkalian Dasar','Belajar perkalian sebagai cara cepat menjumlahkan angka yang sama berulang kali.','sulit',NULL,'Matematika','2026-06-14 11:59:41','2026-06-14 11:59:41');
/*!40000 ALTER TABLE `modul` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-14 23:39:21
