-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: jejak-kecil
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kuis`
--

DROP TABLE IF EXISTS `kuis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kuis` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_modul` bigint unsigned NOT NULL,
  `pertanyaan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `gambar_pertanyaan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pilihan_a` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pilihan_b` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pilihan_c` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pilihan_d` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jawaban_benar` enum('a','b','c','d') COLLATE utf8mb4_unicode_ci NOT NULL,
  `poin` int NOT NULL DEFAULT '100',
  `urutan` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kuis_id_modul_foreign` (`id_modul`),
  CONSTRAINT `kuis_id_modul_foreign` FOREIGN KEY (`id_modul`) REFERENCES `modul` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kuis`
--

LOCK TABLES `kuis` WRITE;
/*!40000 ALTER TABLE `kuis` DISABLE KEYS */;
INSERT INTO `kuis` VALUES (11,2,'Angka pertama dalam urutan bilangan adalah?',NULL,'1','2','3','4','a',20,1,'2026-06-14 10:36:04','2026-06-14 10:36:04'),(12,2,'Angka setelah 1 adalah?',NULL,'3','4','2','5','c',20,2,'2026-06-14 10:36:04','2026-06-14 10:36:04'),(13,2,'Angka sebelum 4 adalah?',NULL,'1','2','3','5','c',20,3,'2026-06-14 10:36:04','2026-06-14 10:36:04'),(14,2,'Angka kelima dalam urutan adalah?',NULL,'3','4','5','6','c',20,4,'2026-06-14 10:36:04','2026-06-14 10:36:04'),(15,2,'Angka setelah 9 adalah?',NULL,'8','10','11','12','b',20,5,'2026-06-14 10:36:04','2026-06-14 10:36:04'),(16,1,'Huruf pertama dalam alfabet adalah?',NULL,'A','B','C','D','a',20,1,'2026-06-14 10:37:30','2026-06-14 10:37:30'),(17,1,'Huruf setelah A adalah?',NULL,'C','D','B','E','c',20,2,'2026-06-14 10:37:30','2026-06-14 10:37:30'),(18,1,'Huruf sebelum D adalah?',NULL,'A','B','C','E','c',20,3,'2026-06-14 10:37:30','2026-06-14 10:37:30'),(19,1,'Huruf ketiga dalam alfabet adalah?',NULL,'A','B','C','D','c',20,4,'2026-06-14 10:37:30','2026-06-14 10:37:30'),(20,1,'Huruf setelah C adalah?',NULL,'B','D','E','F','b',20,5,'2026-06-14 10:37:30','2026-06-14 10:37:30'),(21,3,'Apa saja yang termasuk warna primer?',NULL,'merah, kuning, biru','merah, hijau, biru','merah, oranye, ungu','kuning, hijau, ungu','a',20,1,'2026-06-14 04:21:29','2026-06-14 04:21:29'),(22,3,'Warna apa yang dihasilkan jika mencampur warna merah dan kuning',NULL,'ungu','hijau','oranye','coklat','c',20,2,'2026-06-14 04:22:37','2026-06-14 04:43:53'),(23,3,'Warna apa yang dihasilkan jika mencampur warna biru dan kuning?',NULL,'oranye','ungu','coklat','hijau','d',20,3,'2026-06-14 04:43:15','2026-06-14 04:43:15'),(24,3,'Manakah yang termasuk warna sekunder?',NULL,'merah','kuning','ungu','biru','c',20,4,'2026-06-14 04:44:38','2026-06-14 04:44:38'),(25,3,'Warna apa yang dihasilkan jika mencampur warna merah dan biru',NULL,'hijau','ungu','oranye','abu-abu','b',20,5,'2026-06-14 04:45:30','2026-06-14 04:45:30'),(26,5,'Berapa hasil dari 3 + 4?',NULL,'6','8','7','5','c',20,1,'2026-06-14 11:59:30','2026-06-14 11:59:30'),(27,5,'Berapa hasil dari 5 + 5?',NULL,'9','10','11','8','b',20,2,'2026-06-14 11:59:30','2026-06-14 11:59:30'),(28,5,'Dina punya 4 permen, lalu diberi 3 permen lagi. Berapa total permen Dina?',NULL,'6','8','5','7','d',20,3,'2026-06-14 11:59:30','2026-06-14 11:59:30'),(29,5,'Berapa hasil dari 6 + 3?',NULL,'8','10','9','7','c',20,4,'2026-06-14 11:59:30','2026-06-14 11:59:30'),(30,5,'Angka berapa yang harus ditambahkan ke 7 agar hasilnya 10?',NULL,'2','4','3','5','c',20,5,'2026-06-14 11:59:30','2026-06-14 11:59:30'),(31,6,'Berapa hasil dari 8 - 3?',NULL,'4','6','5','3','c',20,1,'2026-06-14 11:59:38','2026-06-14 11:59:38'),(32,6,'Ada 10 balon, lalu 4 balon meletus. Berapa sisa balon?',NULL,'5','7','6','8','c',20,2,'2026-06-14 11:59:38','2026-06-14 11:59:38'),(33,6,'Berapa hasil dari 9 - 9?',NULL,'1','0','9','2','b',20,3,'2026-06-14 11:59:38','2026-06-14 11:59:38'),(34,6,'Ibu punya 7 telur, dipakai 3 untuk memasak. Berapa sisa telur?',NULL,'3','5','4','2','c',20,4,'2026-06-14 11:59:38','2026-06-14 11:59:38'),(35,6,'Berapa hasil dari 10 - 6?',NULL,'3','5','4','6','c',20,5,'2026-06-14 11:59:38','2026-06-14 11:59:38'),(36,7,'Berapa hasil dari 3 × 4?',NULL,'10','14','12','8','c',25,1,'2026-06-14 11:59:47','2026-06-14 11:59:47'),(37,7,'Ada 5 kotak, setiap kotak berisi 3 bola. Berapa total bola?',NULL,'8','15','10','12','b',25,2,'2026-06-14 11:59:47','2026-06-14 11:59:47'),(38,7,'Berapa hasil dari 2 × 7?',NULL,'9','16','12','14','d',25,3,'2026-06-14 11:59:47','2026-06-14 11:59:47'),(39,7,'Perkalian mana yang hasilnya 20?',NULL,'3 × 6','4 × 6','4 × 5','5 × 3','c',25,4,'2026-06-14 11:59:47','2026-06-14 11:59:47'),(40,7,'Berapa hasil dari 5 × 5?',NULL,'20','30','10','25','d',25,5,'2026-06-14 11:59:47','2026-06-14 11:59:47');
/*!40000 ALTER TABLE `kuis` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-14 23:39:20
