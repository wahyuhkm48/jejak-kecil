-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: jejak-kecil
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jadwal_konsultasi`
--

DROP TABLE IF EXISTS `jadwal_konsultasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jadwal_konsultasi` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_pengguna` bigint unsigned NOT NULL,
  `id_spesialis` bigint unsigned NOT NULL,
  `judul_sesi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `waktu_mulai` datetime NOT NULL,
  `waktu_selesai` datetime DEFAULT NULL,
  `status` enum('akan_datang','selesai','dibatalkan') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'akan_datang',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jadwal_konsultasi_id_pengguna_foreign` (`id_pengguna`),
  KEY `jadwal_konsultasi_id_spesialis_foreign` (`id_spesialis`),
  CONSTRAINT `jadwal_konsultasi_id_pengguna_foreign` FOREIGN KEY (`id_pengguna`) REFERENCES `pengguna` (`id`) ON DELETE CASCADE,
  CONSTRAINT `jadwal_konsultasi_id_spesialis_foreign` FOREIGN KEY (`id_spesialis`) REFERENCES `spesialis` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_konsultasi`
--

LOCK TABLES `jadwal_konsultasi` WRITE;
/*!40000 ALTER TABLE `jadwal_konsultasi` DISABLE KEYS */;
INSERT INTO `jadwal_konsultasi` VALUES (1,1,1,'Konsultasi Awal','2026-06-20 09:00:00','2026-06-20 10:00:00','akan_datang',NULL,NULL),(2,2,1,'Konsultasi Awal','2026-06-15 15:00:00',NULL,'akan_datang','2026-06-14 05:00:53','2026-06-14 05:00:53'),(3,2,4,'Evaluasi Perkembangan','2026-06-17 09:00:00',NULL,'akan_datang','2026-06-14 06:50:50','2026-06-14 06:50:50'),(4,3,4,'Konsultasi Awal','2026-06-16 10:00:00',NULL,'akan_datang','2026-06-14 09:15:07','2026-06-14 09:15:07');
/*!40000 ALTER TABLE `jadwal_konsultasi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-14 23:39:22
