-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: jejak-kecil
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `avatar_shop`
--

DROP TABLE IF EXISTS `avatar_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avatar_shop` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nama_avatar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gambar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `harga_poin` int NOT NULL DEFAULT '250',
  `warna_background` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#FF8C00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar_shop`
--

LOCK TABLES `avatar_shop` WRITE;
/*!40000 ALTER TABLE `avatar_shop` DISABLE KEYS */;
INSERT INTO `avatar_shop` VALUES (1,'Nana','nana.png',250,'#FF8C00',1,'2026-06-14 09:33:13','2026-06-14 09:33:13'),(2,'Andrey','andrey.png',250,'#1B6B3A',1,'2026-06-14 09:33:13','2026-06-14 09:33:13'),(3,'Lucas','lucas.png',250,'#FFD700',1,'2026-06-14 09:33:13','2026-06-14 09:33:13'),(4,'Guma','guma.png',0,'#C8F5C8',1,'2026-06-14 09:33:13','2026-06-14 09:33:13'),(5,'Lola','Lola.png',150,'#FF8C00',1,'2026-06-14 12:39:51','2026-06-14 12:39:51'),(6,'Ariel','Ariel.png',100,'#1B6B3A',1,'2026-06-14 12:39:51','2026-06-14 12:39:51'),(7,'Cici','Cici.png',250,'#FFD700',1,'2026-06-14 12:39:51','2026-06-14 12:39:51'),(8,'Ronaldo','Ronaldo.png',200,'#C8F5C8',1,'2026-06-14 12:39:51','2026-06-14 12:39:51'),(9,'Sura','Sura.png',50,'#C8F5C8',1,'2026-06-14 12:39:51','2026-06-14 12:39:51'),(10,'Wise','Wise.png',350,'#C8F5C8',1,'2026-06-14 12:39:51','2026-06-14 12:39:51');
/*!40000 ALTER TABLE `avatar_shop` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-14 23:39:21
