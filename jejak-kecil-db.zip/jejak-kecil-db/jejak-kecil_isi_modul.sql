-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: jejak-kecil
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `isi_modul`
--

DROP TABLE IF EXISTS `isi_modul`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `isi_modul` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `id_modul` bigint unsigned NOT NULL,
  `tipe_konten` enum('video','teks','gambar','audio') COLLATE utf8mb4_unicode_ci NOT NULL,
  `isi_konten` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `urutan` int NOT NULL DEFAULT '1',
  `judul_konten` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi_konten` text COLLATE utf8mb4_unicode_ci,
  `durasi_menit` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `isi_modul_id_modul_foreign` (`id_modul`),
  CONSTRAINT `isi_modul_id_modul_foreign` FOREIGN KEY (`id_modul`) REFERENCES `modul` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `isi_modul`
--

LOCK TABLES `isi_modul` WRITE;
/*!40000 ALTER TABLE `isi_modul` DISABLE KEYS */;
INSERT INTO `isi_modul` VALUES (2,1,'video','https://youtu.be/D2DplbqsLw4?si=doI5td-aWJkBNfvb',1,'Pengenalan Huruf A','Belajar mengenal bentuk dan bunyi huruf A',NULL,'2026-06-14 09:34:22','2026-06-14 09:34:22'),(3,2,'video','https://youtu.be/byctrEiAA9U?si=_ZzIZ1JLTPctnP7b',2,'Video Mengenal Angka','Video pembelajaran angka 1 sampai 10',5,'2026-06-14 09:37:02','2026-06-14 09:37:02'),(6,3,'video','https://youtu.be/CdbBFvN3YTI?si=ZuoxTwYxuINR2oZu',1,NULL,NULL,NULL,'2026-06-14 04:40:52','2026-06-14 04:40:52'),(7,5,'teks','Penjumlahan adalah menggabungkan dua angka atau lebih menjadi satu jumlah total. Tanda penjumlahan adalah + (plus).\n\nContoh:\n• 1 + 1 = 2\n• 2 + 3 = 5\n• 4 + 4 = 8\n• 5 + 5 = 10\n• 6 + 3 = 9',1,'Apa itu Penjumlahan?','Pengenalan konsep penjumlahan dasar',NULL,'2026-06-14 11:59:26','2026-06-14 11:59:26'),(8,5,'teks','Cara mudah belajar penjumlahan menggunakan jari:\n\n1. Tunjukkan angka pertama dengan jari tangan kiri\n2. Tunjukkan angka kedua dengan jari tangan kanan\n3. Hitung semua jari yang ditunjukkan\n4. Itulah hasil penjumlahannya!\n\nContoh: 3 + 4\n→ Tunjukkan 3 jari kiri + 4 jari kanan\n→ Hitung semua = 7\n→ Jadi 3 + 4 = 7',2,'Cara Berhitung dengan Jari','Tips penjumlahan menggunakan jari tangan',NULL,'2026-06-14 11:59:26','2026-06-14 11:59:26'),(9,5,'teks','Mari berlatih penjumlahan!\n\n2 + 3 = ?\nBayangkan 2 apel, lalu tambah 3 apel lagi.\nTotal = 5 apel. Jadi 2 + 3 = 5 ✓\n\n4 + 5 = ?\nBayangkan 4 bola, lalu tambah 5 bola lagi.\nTotal = 9 bola. Jadi 4 + 5 = 9 ✓\n\n6 + 4 = ?\nBayangkan 6 bintang, lalu tambah 4 bintang lagi.\nTotal = 10 bintang. Jadi 6 + 4 = 10 ✓',3,'Latihan Penjumlahan','Contoh soal penjumlahan dengan ilustrasi',NULL,'2026-06-14 11:59:26','2026-06-14 11:59:26'),(10,6,'teks','Pengurangan adalah mengambil sejumlah dari angka yang ada. Tanda pengurangan adalah - (minus).\n\nContoh:\n• 5 - 2 = 3\n• 8 - 3 = 5\n• 10 - 4 = 6\n• 7 - 7 = 0\n• 9 - 5 = 4',1,'Apa itu Pengurangan?','Pengenalan konsep pengurangan dasar',NULL,'2026-06-14 11:59:37','2026-06-14 11:59:37'),(11,6,'teks','Cara mudah belajar pengurangan:\n\nBayangkan kamu punya 5 kue di piring.\nLalu kamu makan 2 kue.\nSisa kue di piring = 5 - 2 = 3 kue.\n\nBayangkan ada 8 burung di pohon.\nLalu 3 burung terbang pergi.\nSisa burung = 8 - 3 = 5 burung.\n\nKunci pengurangan:\n→ Mulai dari angka besar\n→ Kurangi dengan angka kecil\n→ Hasilnya selalu lebih kecil atau sama',2,'Konsep Pengurangan','Memahami pengurangan dengan ilustrasi',NULL,'2026-06-14 11:59:37','2026-06-14 11:59:37'),(12,6,'teks','Mari berlatih pengurangan!\n\n10 - 3 = ?\nMulai dari 10, mundur 3 langkah: 9, 8, 7\nJawaban: 10 - 3 = 7 ✓\n\n9 - 4 = ?\nMulai dari 9, mundur 4 langkah: 8, 7, 6, 5\nJawaban: 9 - 4 = 5 ✓\n\n6 - 6 = ?\nJika angka yang dikurangi sama, hasilnya selalu 0\nJawaban: 6 - 6 = 0 ✓',3,'Latihan Pengurangan','Contoh soal pengurangan dengan cara mundur',NULL,'2026-06-14 11:59:37','2026-06-14 11:59:37'),(13,7,'teks','Perkalian adalah cara cepat untuk menjumlahkan angka yang sama secara berulang. Tanda perkalian adalah × (kali).\n\nContoh:\n• 2 × 3 = 2 + 2 + 2 = 6\n• 3 × 4 = 3 + 3 + 3 + 3 = 12\n• 5 × 2 = 5 + 5 = 10\n• 4 × 3 = 4 + 4 + 4 = 12\n\nIngat: 2 × 3 sama dengan 3 × 2, hasilnya tetap 6!',1,'Apa itu Perkalian?','Pengenalan konsep perkalian sebagai penjumlahan berulang',NULL,'2026-06-14 11:59:45','2026-06-14 11:59:45'),(14,7,'teks','Tabel Perkalian 1-5:\n\n× 1 = angka itu sendiri\n1×1=1, 2×1=2, 3×1=3, 4×1=4, 5×1=5\n\n× 2 = selalu bilangan genap\n1×2=2, 2×2=4, 3×2=6, 4×2=8, 5×2=10\n\n× 3\n1×3=3, 2×3=6, 3×3=9, 4×3=12, 5×3=15\n\n× 4\n1×4=4, 2×4=8, 3×4=12, 4×4=16, 5×4=20\n\n× 5 = selalu berakhir 0 atau 5\n1×5=5, 2×5=10, 3×5=15, 4×5=20, 5×5=25',2,'Tabel Perkalian 1-5','Hafalan tabel perkalian angka 1 sampai 5',NULL,'2026-06-14 11:59:45','2026-06-14 11:59:45'),(15,7,'teks','Tips mudah mengingat perkalian:\n\n? Perkalian dengan 1: hasilnya selalu angka itu sendiri\n   5 × 1 = 5\n\n? Perkalian dengan 2: hasilnya selalu ganda\n   6 × 2 = 12 (enam ditambah enam)\n\n? Perkalian dengan 5: hasilnya selalu berakhir 0 atau 5\n   3 × 5 = 15\n   4 × 5 = 20\n\n? Perkalian dengan 10: tinggal tambahkan angka 0\n   3 × 10 = 30\n   7 × 10 = 70',3,'Tips Hafalan Perkalian','Trik mudah mengingat hasil perkalian',NULL,'2026-06-14 11:59:45','2026-06-14 11:59:45');
/*!40000 ALTER TABLE `isi_modul` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-14 23:39:21
